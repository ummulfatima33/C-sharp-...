﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace introduction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "fatima";
            int age = 10;
            string city = "karachi";
            Console.WriteLine("Student Name is " + name);
            Console.Write("Student  Age is " + age);
            Console.WriteLine(" Student City is " + city);
            Console.WriteLine("Student Name is " + name + "  Student City is " + city);

            int input1 = 12;
            int input2 = 50;
            Console.WriteLine(input1 + input2);
            Console.WriteLine(input1 - input2);
            Console.WriteLine(input1 * input2);
            Console.WriteLine(input1 / input2);
            Console.WriteLine(input1 % input2);




        }
        }
    }

